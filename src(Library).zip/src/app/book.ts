export class Book {
    bookId?:number;
    bookName:string;
    bookPrice:number;

}
