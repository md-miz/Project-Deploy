import { Book } from "./book";

export class Category {
    catId:number;
    catName:string;
    book:Book[];    
}
